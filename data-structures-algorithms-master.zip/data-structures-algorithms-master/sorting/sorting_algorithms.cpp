#include<iostream>
#include<vector>
using namespace std;

void bubbleSort(vector<int>& a){int n=a.size();for(int i=0;i<n-1;i++)for(int j=0;j<n-i-1;j++)if(a[j]>a[j+1])swap(a[j],a[j+1]);}

void selectionSort(vector<int>& a){int n=a.size();for(int i=0;i<n-1;i++){int m=i;for(int j=i+1;j<n;j++)if(a[j]<a[m])m=j;swap(a[i],a[m]);}}

void merge(vector<int>& a,int l,int m,int r){vector<int> L(a.begin()+l,a.begin()+m+1),R(a.begin()+m+1,a.begin()+r+1);int i=0,j=0,k=l;while(i<L.size()&&j<R.size())a[k++]=(L[i]<=R[j])?L[i++]:R[j++];while(i<L.size())a[k++]=L[i++];while(j<R.size())a[k++]=R[j++];}
void mergeSort(vector<int>& a,int l,int r){if(l<r){int m=l+(r-l)/2;mergeSort(a,l,m);mergeSort(a,m+1,r);merge(a,l,m,r);}}

int main(){vector<int> arr={64,34,25,12,22,11,90};mergeSort(arr,0,arr.size()-1);for(int x:arr)cout<<x<<' ';return 0;}
