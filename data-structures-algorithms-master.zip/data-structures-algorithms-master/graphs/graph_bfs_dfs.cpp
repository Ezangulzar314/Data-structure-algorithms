#include<iostream>
#include<vector>
#include<queue>
using namespace std;

class Graph{int V;vector<vector<int>> adj;public:Graph(int v):V(v),adj(v){}void addEdge(int u,int v){adj[u].push_back(v);adj[v].push_back(u);}void BFS(int s){vector<bool> vis(V,false);queue<int> q;vis[s]=true;q.push(s);while(!q.empty()){int n=q.front();q.pop();cout<<n<<' ';for(int nb:adj[n])if(!vis[nb]){vis[nb]=true;q.push(nb);}}}void DFSUtil(int v,vector<bool>& vis){vis[v]=true;cout<<v<<' ';for(int nb:adj[v])if(!vis[nb])DFSUtil(nb,vis);}void DFS(int s){vector<bool> vis(V,false);DFSUtil(s,vis);}};

int main(){Graph g(6);g.addEdge(0,1);g.addEdge(0,2);g.addEdge(1,3);g.addEdge(2,4);g.addEdge(3,5);cout<<"BFS: ";g.BFS(0);cout<<endl<<"DFS: ";g.DFS(0);cout<<endl;return 0;}
