# Data Structures & Algorithms

Implementations of core DSA concepts in **C++** and **Python** � covered as part of B.Tech CSE curriculum.

## Topics Covered

| Topic | Language |
|-------|----------|
| Arrays & Strings | C++ |
| Linked Lists | C++ |
| Stacks & Queues | C++ |
| Trees & BST | C++ |
| Graphs (BFS/DFS) | C++ / Python |
| Sorting Algorithms | C++ |
| Dynamic Programming | Python |

## How to Run
```bash
g++ -o output file.cpp && ./output
python3 file.py
```

